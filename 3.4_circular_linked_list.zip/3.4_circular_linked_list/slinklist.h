#include <stdio.h>
#include <stdlib.h>
typedef int datatype;
typedef struct link_node {
    datatype info;
    struct link_node *next;
} node;

